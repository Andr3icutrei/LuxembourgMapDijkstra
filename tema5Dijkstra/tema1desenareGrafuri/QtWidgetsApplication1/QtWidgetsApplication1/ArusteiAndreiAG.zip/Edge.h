#pragma once
#include "Node.h"
#include <iostream>

class Edge
{
private:
	Node* m_first,*m_second;
public:
	Edge();
	Edge(Node*& node1,Node*& node2);

	Node* GetFirstNode() const;
	Node* GetSecondNode() const;

	bool operator==(const Edge& edge);
	~Edge();
	friend std::ostream& operator<<(std::ostream& os, const Edge& currEdge);
};

