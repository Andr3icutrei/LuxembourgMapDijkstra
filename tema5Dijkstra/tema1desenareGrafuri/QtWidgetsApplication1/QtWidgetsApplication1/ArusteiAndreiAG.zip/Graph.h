#pragma once
#include "Edge.h"
#include <vector>

class Graph
{
private:
	std::vector<Node*> m_nodes;
	std::vector<Edge> m_edges;
	std::vector<std::vector<int>> m_adjMatrix;
	std::vector<std::vector<Edge>> m_adjList;
	bool m_isOriented = true;
public:
	Graph()=default;
	Graph(const Graph&) = default;
	Graph& operator=(const Graph&) = default;
	~Graph()=default;

	void addNode(int x,int y);
	void addEdge(Node*& node1, Node*& node2);
	
	bool nodesOverlap(Node*& node1,Node*& node2);

	void writeAdjMatrix();
	void writeAdjList();

	void SetOrientation(bool orientation) { m_isOriented = orientation; }

	std::vector<std::vector<Edge>> GetAdjList() const{ return m_adjList; }
	std::vector<std::vector<int>> GetAdjMatrix() const { return m_adjMatrix; }
	std::vector<Node*> GetNodes();
	std::vector<Edge> GetEdges();
	bool GetIsOriented() const { return m_isOriented; }
};

