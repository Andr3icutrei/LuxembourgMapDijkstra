#include "Graph.h"
#include <fstream>

void Graph::addNode(int x,int y)
{
	Node* currNode = new Node{ x,y };
	currNode->SetValue(++Node::numberOfNodes);
	m_nodes.emplace_back(currNode);
	m_adjMatrix.resize(m_nodes.size());
	m_adjList.resize(m_nodes.size());
	for (int i = 0; i < m_adjMatrix.size(); ++i)
	{
		m_adjMatrix[i].resize(m_nodes.size());
	}
}

void Graph::addEdge(Node*& node1, Node*& node2)
{
	Edge currEdge(node1, node2);
	m_edges.emplace_back(currEdge);

	if (m_isOriented == false)
	{
		m_adjMatrix[node2->GetValue() - 1][node1->GetValue() - 1] = 1;
		Edge invertedEdge(node2, node1);
		m_adjList[node2->GetValue() - 1].emplace_back(invertedEdge);
	}
	m_adjMatrix[node1->GetValue() - 1][node2->GetValue() - 1] = 1;
	m_adjList[node1->GetValue() - 1].emplace_back(currEdge);
}

std::vector<Node*> Graph::GetNodes()
{
	return m_nodes;
}

std::vector<Edge> Graph::GetEdges()
{
	return m_edges;
}

void Graph::writeAdjMatrix()
{
	std::ofstream fout{ "adjMatrix.txt" };
	fout << m_adjMatrix.size()<<'\n';
	if (m_isOriented == true)
	{
		for (int i = 0; i < m_adjMatrix.size(); ++i)
		{
			for (int j = 0; j < m_adjMatrix.size(); ++j)
				fout << m_adjMatrix[i][j] << " ";
			fout << '\n';
		}
	}
	else
	{
		for (int i = 0; i < m_adjMatrix.size(); ++i)
		{
			for (int j = 0; j < m_adjMatrix.size(); ++j)
			{
				fout << m_adjMatrix[i][j] << " ";
			}
			fout << '\n';
		}
	}
	fout.close();
}

void Graph::writeAdjList()
{
	std::ofstream fout("adjList.txt");
	for (int i = 0; i < m_adjList.size(); ++i)
	{
		fout << i + 1 << ":";
		for (int j = 0; j < m_adjList[i].size(); ++j)
		{
			fout << '(' << m_adjList[i][j] << "),";
		}
		fout << '\n';
	}

	fout.close();
}

bool Graph::nodesOverlap(Node*& node1, Node*& node2)
{
    int x1 = node1->GetX();
    int y1 = node1->GetY();
    int x2 = node2->GetX();
    int y2 = node2->GetY();

    double distance = std::sqrt(std::pow(x2 - x1, 2) + std::pow(y2 - y1, 2));

    return distance <= 2 * Node::m_radius;
}


