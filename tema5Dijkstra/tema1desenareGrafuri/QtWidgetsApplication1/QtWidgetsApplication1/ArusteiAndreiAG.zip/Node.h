#pragma once
#include <qpoint.h>
#include <cstdint>
#include <QMouseEvent>

class Node
{
private:
	QPoint m_position;
	int m_value;
	bool m_isDragging;
public:
	static uint8_t numberOfNodes;
	static const uint8_t m_radius = 15;

	Node(int x,int y);

	int GetX() const;
	int GetY() const;
	int GetValue() const;
	int GetRadius() const;
	QPoint GetPosition()const;

	void SetValue(int newValue);
	void SetPosition(int x,int y);

	bool operator==(const Node * &node);
};
