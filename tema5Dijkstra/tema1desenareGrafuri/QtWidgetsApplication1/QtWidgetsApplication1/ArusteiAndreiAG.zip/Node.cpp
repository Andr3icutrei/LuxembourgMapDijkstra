#include "Node.h"
#include <QMouseEvent>
#include <qwidget.h>


uint8_t Node::numberOfNodes = 0;

Node::Node(int x, int y)
{
	m_position = QPoint(x, y);
}

int Node::GetX() const
{
	return m_position.x();
}

int Node::GetY() const
{
	return m_position.y();
}

int Node::GetValue() const
{
	return m_value;
}

int Node::GetRadius() const
{
	return m_radius;
}

QPoint Node::GetPosition() const
{
	return m_position;
}

void Node::SetValue(int newValue)
{
	m_value = newValue;
}

void Node::SetPosition(int x,int y)
{
	m_position.setX(x);
	m_position.setY(y);
}

bool Node::operator==(const Node*& node)
{
	return (m_position.x() == node->m_position.x() && m_position.y() == node->m_position.y());
}
