#pragma once
#include <qapplication.h>
#include <QtWidgets/QMainWindow>
#include "ui_QtWidgetsApplication1.h"   
#include <QMouseEvent>
#include "Graph.h"
#include <qpushbutton.h>

class QtWidgetsApplication1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit QtWidgetsApplication1(QWidget *parent = nullptr);
    ~QtWidgetsApplication1();

    void mouseReleaseEvent(QMouseEvent* m) override;
    void paintEvent(QPaintEvent* ev) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event)override;

    void drawArrow(QPainter& p, const QPoint& start, const QPoint& end);
    bool canDrawNode(int xCurr,int yCurr);
    bool isMultigraph(const Edge& currEdge);
    
private:
    QPushButton* pushButton1;

    Ui::QtWidgetsApplication1Class* ui;

    QPoint m_mousePos;

    Graph m_graph;

    Node* selectedNode1=nullptr, *selectedNode2=nullptr;

    Node* m_draggedNode = nullptr;
private slots:
    void onPushButton1Clicked();
};
